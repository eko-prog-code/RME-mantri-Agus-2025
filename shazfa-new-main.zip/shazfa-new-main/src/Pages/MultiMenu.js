import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './MultiMenu.css';
import PatientCard from './PatientCard';

const MultiMenu = () => {
  const [patientList, setPatientList] = useState([]);
  const [indexedPatientList, setIndexedPatientList] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    fetchPatientList();
    fetchIndexedPatientList();
  }, []);

  const fetchPatientList = async () => {
    try {
      const response = await axios.get(
        'https://rme-shazfa-mounira-default-rtdb.firebaseio.com/patients.json'
      );
      if (response.data) {
        const patients = Object.keys(response.data).map((key) => ({
          id: key,
          ...response.data[key],
          isVisible: false,
          isChecked: false,
          StatusPeriksa: response.data[key].StatusPeriksa || false,
        }));
        setPatientList(patients);
      } else {
        setPatientList([]);
      }
    } catch (error) {
      console.error('Error fetching patient list:', error);
      setPatientList([]);
    }
  };

  const fetchIndexedPatientList = async () => {
    try {
      const response = await axios.get(
        'https://rme-shazfa-mounira-default-rtdb.firebaseio.com/indexedPatients.json'
      );
      if (response.data) {
        setIndexedPatientList(response.data);
      }
    } catch (error) {
      console.error('Error fetching indexed patient list:', error);
    }
  };

  const saveIndexedPatientList = async (list) => {
    try {
      await axios.put(
        'https://rme-shazfa-mounira-default-rtdb.firebaseio.com/indexedPatients.json',
        list
      );
    } catch (error) {
      console.error('Error saving indexed patient list:', error);
    }
  };

  const handleAddToListClick = async (patientId) => {
    try {
      const currentPatientIndex = await getLastUsedIndex();
      const newPatientIndex = currentPatientIndex + 1;

      const selectedPatient = patientList.find((patient) => patient.id === patientId);

      if (selectedPatient && !selectedPatient.isIndexed) {
        selectedPatient.isIndexed = true;
        selectedPatient.isVisible = true;
        selectedPatient.PatientIndex = newPatientIndex;
        selectedPatient.index = newPatientIndex;
        selectedPatient.StatusPeriksa = false;

        await axios.put(
          `https://rme-shazfa-mounira-default-rtdb.firebaseio.com/patients/${patientId}.json`,
          selectedPatient
        );

        await updateLastUsedIndex(newPatientIndex);

        const updatedList = [...indexedPatientList, selectedPatient];
        setIndexedPatientList(updatedList);
        saveIndexedPatientList(updatedList);
      }
    } catch (error) {
      console.error('Error adding patient to list:', error);
    }
  };

  const getLastUsedIndex = async () => {
    try {
      const response = await axios.get(
        'https://rme-shazfa-mounira-default-rtdb.firebaseio.com/lastUsedIndex.json'
      );
      return response.data || 0;
    } catch (error) {
      console.error('Error fetching last used index:', error);
      return 0;
    }
  };

  const updateLastUsedIndex = async (newIndex) => {
    try {
      await axios.put(
        'https://rme-shazfa-mounira-default-rtdb.firebaseio.com/lastUsedIndex.json',
        newIndex
      );
    } catch (error) {
      console.error('Error updating last used index:', error);
    }
  };

  const deleteAllIndexes = async () => {
    const isConfirmed = window.confirm("Apakah Anda Yakin akan menghapus Data ini?");
    if (isConfirmed) {
      try {
        const updatedPatients = await Promise.all(
          patientList.map(async (patient) => {
            if (patient.isIndexed) {
              const { isIndexed, isVisible, isChecked, index, StatusPeriksa, PatientIndex, ...restPatientData } = patient;
              await axios.put(
                `https://rme-shazfa-mounira-default-rtdb.firebaseio.com/patients/${patient.id}.json`,
                restPatientData
              );
              return restPatientData;
            }
            return patient;
          })
        );

        await axios.delete(
          'https://rme-shazfa-mounira-default-rtdb.firebaseio.com/lastUsedIndex.json'
        );
        await axios.delete(
          'https://rme-shazfa-mounira-default-rtdb.firebaseio.com/indexedPatients.json'
        );

        setPatientList(updatedPatients);
        setIndexedPatientList([]);
      } catch (error) {
        console.error('Error deleting all indexes:', error);
      }
    }
  };

  const handleDeleteClick = async (patientId) => {
    const isConfirmed = window.confirm("Apakah Anda yakin akan menghapus data indeksasi untuk pasien ini?");
    if (isConfirmed) {
      try {
        // Cari pasien yang sesuai dengan ID
        const selectedPatient = patientList.find(patient => patient.id === patientId);
  
        if (selectedPatient && selectedPatient.isIndexed) {
          // Hapus atribut indeksasi dan update data pasien
          const { isIndexed, isVisible, isChecked, index, StatusPeriksa, PatientIndex, ...restPatientData } = selectedPatient;
          
          // Pembaruan data pasien, hanya menghapus atribut terkait indeksasi
          await axios.put(
            `https://rme-shazfa-mounira-default-rtdb.firebaseio.com/patients/${patientId}.json`,
            restPatientData
          );
          
          // Pembaruan state pasien di list
          const updatedPatientList = patientList.map(patient => {
            if (patient.id === patientId) {
              return { ...patient, ...restPatientData }; // Memastikan data terupdate tanpa atribut yang dihapus
            }
            return patient;
          });
  
          setPatientList(updatedPatientList);
  
          // Hapus dari list indexedPatients jika ada
          const updatedIndexedPatientList = indexedPatientList.filter(patient => patient.id !== patientId);
          setIndexedPatientList(updatedIndexedPatientList);
          saveIndexedPatientList(updatedIndexedPatientList); // Simpan kembali list yang terupdate
        }
      } catch (error) {
        console.error('Error deleting indexed patient:', error);
      }
    }
  };
  

  const toggleCheckStatus = async (patientId) => {
    try {
      const updatedPatients = patientList.map((patient) => {
        if (patient.id === patientId) {
          return {
            ...patient,
            isChecked: !patient.isChecked,
            StatusPeriksa: !patient.StatusPeriksa,
          };
        }
        return patient;
      });

      const selectedPatient = updatedPatients.find((patient) => patient.id === patientId);

      await axios.put(
        `https://rme-shazfa-mounira-default-rtdb.firebaseio.com/patients/${patientId}.json`,
        selectedPatient
      );

      setPatientList(updatedPatients);

      const updatedIndexedList = indexedPatientList.map((patient) => {
        if (patient.id === patientId) {
          return {
            ...patient,
            isChecked: !patient.isChecked,
            StatusPeriksa: !patient.StatusPeriksa,
          };
        }
        return patient;
      });

      setIndexedPatientList(updatedIndexedList);
      saveIndexedPatientList(updatedIndexedList);
    } catch (error) {
      console.error('Error toggling check status:', error);
    }
  };

  const handleSearchChange = (e) => {
    const searchTerm = e.target.value;
    setSearchTerm(searchTerm);
    const filteredPatients = patientList.map((patient) => {
      if (patient.name) {
        return {
          ...patient,
          isVisible:
            searchTerm === '' ||
            patient.name.toLowerCase().includes(searchTerm.toLowerCase()),
        };
      } else {
        return {
          ...patient,
          isVisible: false,
        };
      }
    });
    setPatientList(filteredPatients);
  };

  const toggleModal = () => {
    setModalOpen(!isModalOpen);
  };

  return (
    <div>
      <div style={{ textAlign: "center" }}>
        <button onClick={toggleModal} className="button-open">
            Buka Antrian Pasien
        </button>
      </div>


      {isModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content">
            <button onClick={toggleModal} style={{color: 'white', backgroundColor: 'red'}} className="button-close">
              ✖
            </button>
            <button onClick={deleteAllIndexes} className="button-delete-all">
              Hapus semua Antrian
            </button>

            <input
              type="text"
              placeholder="Cari Pasien..."
              value={searchTerm}
              onChange={handleSearchChange}
              className="input-modal"
            />

            {searchTerm && (
              <div className="filtered-patients">
                <h2>Filter Patients</h2>
                {patientList
                  .filter((patient) => !patient.isIndexed && patient.isVisible)
                  .map((patient) => (
                    <PatientCard
                      key={patient.id}
                      {...patient}
                      onAddClick={() => handleAddToListClick(patient.id)}
                    />
                  ))}
              </div>
            )}

            <div className="indexed-patients">
              <h2>Antrian Patients</h2>
              {indexedPatientList.map((patient, index) => (
                <PatientCard
                  key={patient.id}
                  {...patient}
                  index={index + 1}
                  onCheckClick={() => toggleCheckStatus(patient.id)}
                  onDeleteClick={() => handleDeleteClick(patient.id)}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MultiMenu;
